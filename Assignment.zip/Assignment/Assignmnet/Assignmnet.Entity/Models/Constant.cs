﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment.Entity.Models
{
    public class Constant
    {
        public enum Disease
        {
            HeartDisease =1,
            BrainDisease =2,
            Surgery = 3,
            Fever =4,
            JointPain=5
        }
    }
}
