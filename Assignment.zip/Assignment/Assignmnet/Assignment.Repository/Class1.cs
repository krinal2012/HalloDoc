﻿namespace Assignment.Repository
{
    public class Class1
    {

    }
}